# -*- coding: utf-8 -*-
import json
import time
import os
from scrapy import cmdline


BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def main():

    crawl_page_dir = os.path.join(BASE_DIR, 'QQ/pagenum/crawl_page.json')
    all_crawl_page_num_dir = os.path.join(BASE_DIR, 'QQ/pagenum/all_crawl_page_num.txt')

    with open(crawl_page_dir, 'r', encoding='utf-8') as f:
        res = json.load(f)
        start = res['start']
        end = res['end']

    time.sleep(2)
    with open(all_crawl_page_num_dir, 'a+', encoding='utf-8') as f:
        f.write(str(res) + '\n')

    time.sleep(2)
    with open(crawl_page_dir, 'w', encoding='utf-8') as f:
        set_start_end = {'start': start + 10, 'end': end + 10}
        json.dump(set_start_end, f)

    time.sleep(2)
    cmdline.execute(['scrapy', 'crawl', 'my_music'])


if __name__ == '__main__':
    main()
