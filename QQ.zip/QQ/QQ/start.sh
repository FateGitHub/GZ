#!/bin/sh
cd /root/qqmusic/QQ
/root/qqmusic/venv/bin/python start.py
