# -*- coding: utf-8 -*-
import scrapy
import json
import asyncio
import aiohttp
import requests
import random
from scrapy_redis.spiders import RedisSpider
import fake_useragent

from QQ.items import QqItem
from QQ.spiders.mysqlPaginationUtil import *


class MyMusicSpider(scrapy.Spider):
    name = 'my_music_up'
    allowed_domains = ['qq.com', 'c.y.qq.com', 'dl.stream.qqmusic.qq.com']
    # start_urls = ['http://qq.com/']

    ua = fake_useragent.UserAgent(use_cache_server=False)

    def get_vkey(self, music_vkey_urls):  # 协程判断是否存在不同音乐品质的url
        vkey_result = []

        async def get(url):
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers={"User-Agent": self.ua['google chrome']}) as resp:
                    if resp.status == 200:
                        html = await resp.read()
                        return html

        async def vkey_request(vkey_url_info):
            url = vkey_url_info[0]
            url_type = vkey_url_info[1]

            response = await get(url)
            response = response.decode('utf-8').split(')MusicJsonCallback(', maxsplit=1)[0].replace(
                'MusicJsonCallback(', '').rstrip(')')
            response = json.loads(response)

            vkey = response['data']['items'][0]['vkey']  # 加密的参数

            if vkey:
                vkey_result.append([vkey, url_type])
            else:
                # 不可下载
                pass

        tasks = [asyncio.ensure_future(vkey_request(vkey_url_info)) for vkey_url_info in music_vkey_urls]
        loop = asyncio.get_event_loop()
        loop.run_until_complete(asyncio.wait(tasks))
        if vkey_result:
            # music_download_url = result[-1]  # 默认下载最高品质
            return vkey_result[-1]
        else:
            return None

    def get_params(self, mid, guid):  # 获取加密的vkey

        params_url = 'https://c.y.qq.com/base/fcgi-bin/fcg_music_express_mobile3.fcg?g_tk=5381&jsonpCallback=MusicJsonCallback' \
                     '&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq&needNewCode=0&cid=205361747' \
                     '&callback=MusicJsonCallback&uin=0&songmid=' + mid + '&filename={}' + mid + '.{}&guid=' + guid

        music_type = {
            'C400': 'm4a',
            'M500': 'mp3',
            'M800': 'mpe',
            'A000': 'ape',
            'F000': 'flac'
        }  # m4a, mp3普通, mp3高, ape, flac
        music_vkey_urls = []  # 下载音乐的地址

        for k, v in music_type.items():
            music_url = params_url.format(k, v)
            music_vkey_urls.append([music_url, (k, v)])

        music_download_url = self.get_vkey(music_vkey_urls)
        return music_download_url

    def start_requests(self):

        # 读取歌曲文件
        conn = get_connect('127.0.0.1', 'root', 'Changeme_123', 'music', 3306)
        pag = MySQLQueryPagination(conn, num_per_page=100)
        sql = r'SELECT * FROM `song` WHERE song_id>%s'
        param = [0]
        # 每页读取100条
        for ret in pag.query_of_start_end_ist(sql, 0, 1, param):
            song_result = next(ret)
            song_lst = song_result[0]
            # 当前页码
            cur_page = song_result[1]
            for song_inf in song_lst:
                songid, songmid, songname, songorig, singernames, songMediaMid, \
                isonly, interval, ranking, albumid, albumname, albumdesc, time_public = song_inf

                mid = songmid
                guid = '1' + ''.join(random.choice(['1', '2', '3', '4', '5', '6', '7', '8', '9']) for _ in range(9))
                params_url = 'https://c.y.qq.com/base/fcgi-bin/fcg_music_express_mobile3.fcg?g_tk=5381&jsonpCallback=MusicJsonCallback' \
                             '&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq&needNewCode=0&cid=205361747' \
                             '&callback=MusicJsonCallback&uin=0&songmid=' + mid + '&filename={}' + mid + '.{}&guid=' + guid

                music_type = {
                    'C400': 'm4a',
                    'M500': 'mp3',
                }  # m4a普通, mp3高

                for k, v in music_type.items():
                    music_url = params_url.format(k, v)

                    res = {
                        # songMediaMid 音频id
                        'music_uuid': songmid,
                        # 歌曲id
                        'song_id': songid,
                        # 歌名 song_name
                        'music_name': songname,
                        # 歌手 singer_names
                        'performer': singernames,
                        # 专辑 album_name
                        'album': albumname,
                        # 歌时长 interval
                        'duration': interval,
                        # 歌词 songMediaMid
                        'music_lyric': songmid,
                        # guid 用户id
                        'guid': guid,
                        # 当前页
                        'cur_page': cur_page
                    }
                    request = scrapy.Request(url=music_url, meta=res, callback=self.parse)

                    yield request

    def parse(self, response):

        song_name = response.meta['music_name']
        song_id = response.meta['song_id']
        mid = response.meta['music_uuid']
        performer = response.meta['performer']
        album = response.meta['album']
        duration = response.meta['duration']
        guid = response.meta['guid']
        cur_page = response.meta['cur_page']

        response = response.text.replace('MusicJsonCallback(', '').rstrip(')')
        response = json.loads(response)
        vkey = response['data']['items'][0]['vkey']  # 加密的参数

        if not vkey:
            # 没有vkey
            with open('crawl_music_fail.txt', 'a+', encoding='utf-8') as f:
                f.write(str((song_id, mid, cur_page)) + '\n')
                f.flush()
        else:
            music_download_url = 'https://dl.stream.qqmusic.qq.com/M500{0}.mp3?&guid={1}&vkey={2}&uin=0&fromtag=66'. \
                format(mid, guid, vkey)

            item = QqItem()

            item['music_uuid'] = mid
            item['song_id'] = song_id
            item['music_name'] = song_name
            item['performer'] = performer
            item['album'] = album
            item['duration'] = duration
            item['music_lyric'] = mid
            item['rate'] = 320
            item['guid'] = guid
            item['music_download_url'] = music_download_url
            item['cur_page'] = cur_page

            yield item


