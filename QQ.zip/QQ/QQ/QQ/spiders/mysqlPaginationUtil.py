# -*- coding:utf-8 -*-
import pymysql


def get_connect(host, user, passwd, db, port, charset="utf8"):
    return pymysql.connect(host=host, user=user, password=passwd,
                           database=db, port=port, charset=charset, )


class MySQLQueryPagination(object):

    def __init__(self, conn, num_per_page=20):
        self.conn = conn
        self.num_per_page = num_per_page

    def query_for_ist(self, sql, param=None):
        '''获取全部数据'''
        total_page_num = self.__cal_total_pages(sql, param)
        for page_index in range(total_page_num):
            yield self.__query_each_page(sql, page_index, param)

    def query_of_start_end_ist(self, sql, start, end, param=None):
        '''获取起始到终止页数据'''
        for page_index in range(start, end):
            yield self.__query_each_page(sql, page_index, param)

    def get_cur_page_sql(self, sql, page_index, param):
        '''获取一页数据'''
        return self.__query_each_page(sql, page_index, param)

    def __create_pagination_query_sql(self, sql, current_page_index):
        start_index = self.__cal_start_index(current_page_index)
        qSql = r'SELECT * FROM (%s) total_table limit %s,%s' % (sql, start_index, self.num_per_page)
        return qSql

    def __query_each_page(self, sql, current_page_index, param=None):
        curs = self.conn.cursor()
        qSql = self.__create_pagination_query_sql(sql, current_page_index)
        if param is None:
            curs.execute(qSql)
        else:
            curs.execute(qSql, param)

        result = curs.fetchall()
        curs.close()
        yield result, current_page_index

    def __cal_start_index(self, current_page_index):
        start_index = current_page_index * self.num_per_page
        return start_index

    def __caltotal_rows_num(self, sql, param=None):
        ''' 计算总行数 '''
        tSql = r'SELECT count(*) FROM (%s) total_table' % sql
        curs = self.conn.cursor()
        if param is None:
            curs.execute(tSql)
        else:
            curs.execute(tSql, param)
        result = curs.fetchone()
        curs.close()
        total_rows_num = 0
        if result != None:
            total_rows_num = int(result[0])
        return total_rows_num

    def __cal_total_pages(self, sql, param):
        '''计算总页数 '''
        total_rows_num = self.__caltotal_rows_num(sql, param)
        total_pages = 0
        if (total_rows_num % self.num_per_page) == 0:
            total_pages = total_rows_num / self.num_per_page
        else:
            total_pages = (total_rows_num / self.num_per_page) + 1

        print(total_pages)
        return int(total_pages)

    def __callast_index(self, total_rows, total_pages, current_page_index):
        '''计算结束时候的索引'''
        last_index = 0
        if total_rows < self.num_per_page:
            last_index = total_rows
        elif ((total_rows % self.num_per_page == 0)
              or (total_rows % self.num_per_page != 0 and current_page_index < total_pages)):
            last_index = current_page_index * self.num_per_page
        elif (total_rows % self.num_per_page != 0 and current_page_index == total_pages):  # 最后一页
            last_index = total_rows
        return last_index


if __name__ == '__main__':
    conn = get_connect('127.0.0.1', 'root', '123456', 'QQ', 3306)
    pag = MySQLQueryPagination(conn, num_per_page=100)
    sql = r'SELECT * FROM `singer` WHERE singer_id>%s'
    param = [0]

    # res = pag.get_cur_page_sql(sql, 0, param)
    # print(next(res))

    # for ret in pag.query_for_ist(sql, param):
    #     print(ret)
    #     pass

    for ret in pag.query_of_start_end_ist(sql, 0, 1, param):
        lst = next(ret)
        print(lst[1])
        # for i in lst[0]:
        #     a, b, c, d, e, f, g, h = i
        #     print(a, b)
    conn.close()
