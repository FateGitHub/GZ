# -*- coding: utf-8 -*-
import json
import time
import os
from scrapy import cmdline


BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def main():

    cmdline.execute(['scrapy', 'crawl', 'download_music'])
    # 36 0 * * 3,7 *

if __name__ == '__main__':
    main()
