# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class NewqqmusicItem(scrapy.Item):
    # songMediaMid 音频id
    music_uuid = scrapy.Field()
    # 歌曲id
    song_id = scrapy.Field()
    # 歌名 song_name
    music_name = scrapy.Field()
    # 歌手 singer_names
    performer = scrapy.Field()
    # 专辑 album_name
    album = scrapy.Field()
    # 专辑mid
    album_mid = scrapy.Field()
    # 歌时长 interval
    duration = scrapy.Field()
    # 歌词 songMediaMid
    music_lyric = scrapy.Field()
    # size 歌曲大小
    size = scrapy.Field()
    # 比特率 320
    rate = scrapy.Field()
    # guid 用户id
    guid = scrapy.Field()
    # 歌曲下载链接
    music_download_url = scrapy.Field()
