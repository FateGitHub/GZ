# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import requests
import pymysql
from fake_useragent import UserAgent
import os
import json


class NewqqmusicPipeline(object):
    def __init__(self):
        self.ua = None
        self.conn = None
        self.cur = None
        self.base_dir = None
        self.music_dir = None
        self.lyric_dir = None

    def open_spider(self, spider):
        self.ua = UserAgent(use_cache_server=False)
        self.conn = pymysql.connect(host='47.244.157.51', user='music', password="musicdhRFF67#@",
                                    database='music', port=4001, charset='utf8mb4')
        self.cur = self.conn.cursor()
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.music_dir = "/home/music"
        self.lyric_dir = "/home/lyric"
        self.album_pic_dir = "/home/albumpic"

    def process_item(self, item, spider):
        music_download_url = item['music_download_url']
        music_uuid = item['music_uuid']
        response = requests.get(url=music_download_url, headers={"User-Agent": self.ua['google chrome']}, stream=True)

        if response.status_code == 200:
            item['size'] = len(response.content)
            if item['size'] < 50000000:
                # 音乐的下载
                music_name = os.path.join(self.music_dir, music_uuid + '.mp3')
                with open(music_name, 'wb') as f:
                    for check in response.iter_content(1024):
                        f.write(check)

                # 歌词下载
                self.getLyric(item['song_id'], item['music_uuid'])
                # 专辑图片下载
                self.get_album_pic(item['album_mid'])

                # 插入到迁移数据库

                sql = "INSERT INTO download_music_info_ready(`music_uuid`,`song_id`,`music_name`,`performer`,`album`,`size`," \
                      "`duration`,`music_small_pic`,`music_big_pic`,`music_radio_pic`,`music_lyric`,`rate`) " \
                      "VALUES (%r,%d,%r,%r,%r,%d,%d,%r,%r,%r,%r,%d)" % (
                          item['music_uuid'], item['song_id'], item['music_name'], item['performer'],
                          item['album'], item['size'], item['duration'], 'T002R90x90M000' + item['album_mid'],
                          'T002R300x300M000' + item['album_mid'], 'T002R300x300M000' + item['album_mid'],
                          item['music_lyric'], item['rate'])
                try:
                    self.cur.execute(sql)
                    self.conn.commit()
                except:
                    # 插入失败
                    with open(os.path.join(self.base_dir, 'log/insert_music_err.log'), 'a+', encoding='utf-8') as f:
                        f.write(str(sql) + '\n')
            else:
                pass

        else:
            # 下载失败
            with open(os.path.join(self.base_dir, 'log/download_music_fail.log'), 'a+', encoding='utf-8') as f:
                f.write(str((item['music_uuid'], item['song_id'], item['music_name'], item['performer'],
                             item['album'], item['album_mid'], item['duration'], item['music_lyric'],
                             item['rate'])) + '\n')

        return item

    def lyrics_2_lrc(self, song_mid, lyrics_info):
        '''
        将lyrics转为.lrc文件
        :param lyrics_info: 歌词信息
        :return:
        '''
        lrc = lyrics_info.replace('&#38;apos&#59;', "'")
        str_dict = {
            "&#9;": " ",
            "&#10;": "\n",
            "&#13;": "",
            "&#32;": " ",
            "&#33;": "!",
            "&#34;": '"',
            "&#36;": "$",
            "&#37;": "%",
            "&#38;": "&",
            "&#39;": "'",
            "&#40;": "(",
            "&#41;": ")",
            "&#42;": "*",
            "&#43;": "+",
            "&#45;": "-",
            "&#46;": ".",
            "&#58;": ":",
            "&#59;": "/",
            "&#63;": "?",
            "&#64;": "@",
            "&#95;": "_",
            "&#96;": "'",
        }

        for key in str_dict:
            lrc = lrc.replace(key, str_dict[key])
        lrc_name = os.path.join(self.lyric_dir, song_mid + '.lrc')

        with open(lrc_name, 'w', encoding='utf-8') as f:
            f.write(lrc)
            f.flush()

    def getLyric(self, song_id, song_mid):
        '''
        根据歌手id获取歌词内容
        :param songid: 歌曲id
        :param songmid: 歌曲mid
        :return:
        '''

        url = 'https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_yqq.fcg'

        header = {
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'origin': 'https://y.qq.com',
            'user-agent': self.ua['google chrome'],
            'referer': 'https://y.qq.com/n/yqq/song/{0}.html'.format(song_mid)
        }
        paramters = {
            "nobase64": "1",
            "musicid": song_id,
            "-": "jsonp1",
            "g_tk": "5381",
            "loginUin": "0",
            "hostUin": "0",
            "format": "json",
            "inCharset": "utf8",
            "outCharset": "utf-8",
            "notice": "0",
            "platform": "yqq.json",
            "needNewCode": "0",
        }

        response = requests.get(url=url, params=paramters, headers=header)

        if response.status_code == 200:
            res = json.loads(response.text.lstrip('MusicJsonCallback(').rstrip(')'))
            # 由于一部分歌曲没有上传歌词,因此没有,默认为空
            if 'lyric' in res:
                lyrics = res['lyric']
                self.lyrics_2_lrc(song_mid, lyrics)
            else:
                lyrics = ""
            # print(lyrics)
            # self.lyrics_2_lrc(song_mid, lyrics)

        else:
            with open(os.path.join(self.base_dir, "log/crawl_song_lyrics_err.log"), 'a+', encoding='utf-8') as f:
                f.write(str(song_id) + '\n')

    def get_album_pic(self, mid):
        '''
        爬取专辑图片 歌曲图片与专辑图片一致
        :param mid: 专辑mid
        :return:
        '''

        big_url = 'https://y.gtimg.cn/music/photo_new/T002R300x300M000{0}.jpg'.format(mid)
        small_url = 'https://y.gtimg.cn/music/photo_new/T002R90x90M000{0}.jpg'.format(mid)

        headers = {
            "Accept": "image/webp,image/apng,image/*,*/*;q=0.8",
            "Referer": "https://y.qq.com/n/yqq/album/{}.html".format(mid),
            "User-Agent": self.ua['google chrome']
        }

        big_response = requests.get(big_url, headers=headers)  # verify=False
        if big_response.status_code == 200:
            album_pic_name = os.path.join(self.album_pic_dir, 'T002R300x300M000' + mid + '.jpg')
            with open(album_pic_name, 'wb') as f:
                f.write(big_response.content)
                f.flush()
        else:
            with open(os.path.join(self.base_dir, 'log/album_pic_err.log'), 'a+', encoding='utf-8') as f:
                f.write('T002R300x300M000' + mid + '\n')

        small_response = requests.get(small_url, headers=headers)  # verify=False
        if small_response.status_code == 200:
            album_pic_name = os.path.join(self.album_pic_dir, 'T002R90x90M000' + mid + '.jpg')
            with open(album_pic_name, 'wb') as f:
                f.write(small_response.content)
                f.flush()
        else:
            with open(os.path.join(self.base_dir, 'log/album_pic_err.log'), 'a+', encoding='utf-8') as f:
                f.write('T002R90x90M000' + mid + '\n')

    def close_spider(self, spider):
        self.cur.close()
        self.conn.close()
