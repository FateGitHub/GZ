# -*- coding: utf-8 -*-
import scrapy
import json
import random
import datetime
import os
import pandas as pd
import time

from NewQQMusic.items import NewqqmusicItem


class MyMusicSpider(scrapy.Spider):
    name = 'download_music'
    allowed_domains = ['qq.com', 'y.qq.com', 'c.y.qq.com', 'dl.stream.qqmusic.qq.com', 'y.gtimg.cn']
    # start_urls = ['http://qq.com/']

    # 日志日期
    today = str(datetime.datetime.today().date())
    yesterday = str(datetime.datetime.today().date() + datetime.timedelta(days=-1))

    # 基目录
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # 日志目录
    crawl_music_fail_log = os.path.join(base_dir, 'log/crawl_music_fail-' + today + '.log')
    yesterday_crawl_music_fail_log = os.path.join(base_dir, 'log/crawl_music_fail-' + yesterday + '.log')

    new_song = os.path.join(base_dir, 'crawlMusicInfo/new_song.csv')
    old_song = os.path.join(base_dir, 'crawlMusicInfo/old_song.csv')

    def remove_yesterday_log(self, log_name):
        '''
        删除昨天日志
        :param log_name:
        :return:
        '''
        if os.path.exists(log_name):
            os.remove(log_name)
        else:
            pass

    def du_song_by_song_id(self, new_song_path, old_song_path):
        # 读取歌文件
        old_song = pd.read_csv(old_song_path, header=None, sep=',', error_bad_lines=False)
        new_song = pd.read_csv(new_song_path, header=None, sep=',', error_bad_lines=False)

        old_song_song_id = old_song[0]
        new_song_song_id = new_song[0]
        # 通过id去重
        not_in = new_song_song_id[~new_song_song_id.isin(old_song_song_id)]
        du_song = new_song.loc[new_song[0].isin(not_in)]
        time.sleep(2)
        if os.path.exists(old_song_path):
            os.remove(old_song_path)
        time.sleep(1)
        du_song.to_csv(old_song_path, index=False, header=False, encoding='utf-8')

    def start_requests(self):
        # 删除昨天日志
        # self.remove_yesterday_log(self.yesterday_crawl_music_fail_log)

        # 去重
        self.du_song_by_song_id(self.new_song, self.old_song)
        time.sleep(2)
        # 读取歌曲文件
        with open(self.old_song, 'r', encoding='utf-8') as f:
            song_lst = f.readlines()

        for song_inf in song_lst:
            songid, songmid, songname, songorig, singernames, songMediaMid, \
            isonly, interval, ranking, albummid, albumname, albumdesc, time_public = eval(song_inf)

            mid = songmid
            guid = '1' + ''.join(random.choice(['1', '2', '3', '4', '5', '6', '7', '8', '9']) for _ in range(9))
            mid_url = 'https://c.y.qq.com/base/fcgi-bin/fcg_music_express_mobile3.fcg?g_tk=5381&jsonpCallback=MusicJsonCallback' \
                      '&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq&needNewCode=0&cid=205361747' \
                      '&callback=MusicJsonCallback&uin=0&songmid={0}&filename=M500{1}.mp3&guid={2}' \
                .format(mid, mid, guid)

            res = {
                # songMediaMid 音频id
                'music_uuid': songmid,
                # 歌曲id
                'song_id': songid,
                # 歌名 song_name
                'music_name': songname,
                # 歌手 singer_names
                'performer': singernames,
                # 专辑 album_name
                'album': albumname,
                # 专辑mid
                'album_mid': albummid,
                # 歌时长 interval
                'duration': interval,
                # 歌词 songMediaMid
                'music_lyric': songmid,
                # guid 用户id
                'guid': guid,

            }
            request = scrapy.Request(url=mid_url, meta=res, callback=self.parse)

            yield request

    def parse(self, response):

        song_name = response.meta['music_name']
        song_id = response.meta['song_id']
        mid = response.meta['music_uuid']
        performer = response.meta['performer']
        album = response.meta['album']
        album_mid = response.meta['album_mid']
        duration = response.meta['duration']
        guid = response.meta['guid']

        response = response.text.replace('MusicJsonCallback(', '').rstrip(')')
        response = json.loads(response)
        vkey = response['data']['items'][0]['vkey']  # 加密的参数

        if not vkey:
            # 没有vkey
            with open(self.crawl_music_fail_log, 'a+', encoding='utf-8') as f:
                f.write(str((song_id, mid, song_name, performer, album, album_mid, duration)) + '\n')

        else:
            music_download_url = 'https://dl.stream.qqmusic.qq.com/M500{0}.mp3?&guid={1}&vkey={2}&uin=0&fromtag=66'. \
                format(mid, guid, vkey)

            item = NewqqmusicItem()

            item['music_uuid'] = mid
            item['song_id'] = song_id
            item['music_name'] = song_name
            item['performer'] = performer
            item['album'] = album
            item['album_mid'] = album_mid
            item['duration'] = duration
            item['music_lyric'] = mid
            item['rate'] = 320
            item['guid'] = guid
            item['music_download_url'] = music_download_url

            yield item
