# -*- coding: utf-8 -*-
import scrapy
import json
import urllib.parse
import fake_useragent
import os


class NewMusicSpider(scrapy.Spider):
    name = 'new_music'
    allowed_domains = ['qq.com', 'y.qq.com', 'c.y.qq.com', 'dl.stream.qqmusic.qq.com', 'y.gtimg.cn']
    start_urls = ['http://y.qq.com/']
    ua = fake_useragent.UserAgent(use_cache_server=False)

    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    new_singer_album_song_table = os.path.join(base_dir, 'crawlMusicInfo/new_singer_album_song_table.txt')
    new_singer = os.path.join(base_dir, 'crawlMusicInfo/new_singer.txt')
    new_song = os.path.join(base_dir, 'crawlMusicInfo/new_song.csv')
    new_album = os.path.join(base_dir, 'crawlMusicInfo/new_album.txt')

    def start_requests(self):
        # 删除新歌文件
        if os.path.exists(self.new_song):
            os.remove(self.new_song)
        '''
        获取新歌
        type:内地1 港台2 欧美3 日本4 韩国5
        '''
        for type in range(1, 6):
            headers = {
                "Referer": "https://y.qq.com/",
                "User-Agent": self.ua['google chrome']
            }
            start_url = "http://u.y.qq.com/cgi-bin/musicu.fcg?&g_tk=5381&loginUin=0&hostUin=0&format=jsonp&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq&needNewCode=0&"

            data = {
                "data": '''{"comm":{"ct":24},"new_song":{"module": "QQMusic.MusichallServer","method": "GetNewSong","param":{"type":%d}}}''' % type
            }

            data = urllib.parse.urlencode(data)
            data = data.replace('+', '')
            start_url += data
            request = scrapy.Request(url=start_url, callback=self.parse, headers=headers)
            request.meta['country'] = type
            yield request

    def parse(self, response):
        """
        album
            id: 专辑id
            mid: 专辑mid "001wMeKI342v8N"
            name: 专辑名 "遗书"
            subtitle: 专辑描述 ""
            time_public: 发行时间 "2018-12-07"
            title: 专辑名 "遗书"

        file
            media_mid: 歌曲mid "000b5WcG2YFNbF" (songmid==strMediaMid)

        title: 歌名
        id: 歌id 223193213
        interval: 时长 255
        isonly: 独家 1

        singer
            id: 47
            mid: "002u0TJy47WWOj"
            name: "林忆莲"
            title: "林忆莲"
            type: 1
        """
        # 新歌列表
        json_res = response.text
        if 'song_list' in json_res:
            new_song_list = json.loads(json_res)['new_song']['data']['song_list']
            country_dict = {1: "内地", 2: "港台", 3: "欧美", 4: "日本", 5: "韩国"}
            type = response.meta['country']
            for song in new_song_list:
    
                song_id = song['id']
                song_mid = song['mid']
                strMediaMid = song['file']['media_mid']
                song_orig = song['title']
                interval = song['interval']
                is_only = song['isonly']
                # strMediaMid = song_mid
    
                album_info = song['album']
                album_id = album_info['id']
                album_mid = album_info['mid']
                album_name = album_info['name']
                album_desc = album_info['subtitle']
                time_public = album_info['time_public']
    
                song_name = song_orig
                if album_desc:
                    album_name += ' --' + album_desc
                if not song_name:
                    song_name = album_name
                # print(song_id, song_name)
    
                singernames = ' / '.join(i.get('name') for i in song['singer'])
                ranking = 0
                singer = song['singer']
                # 歌手数量 > 1
                if len(singer) > 1:
                    for s in singer:
                        singer_id = s.get('id')
    
                        singer_mid = s.get('mid')
                        singer_name = s.get('name')
                        country = country_dict[type]
                        with open(self.new_singer_album_song_table, 'a+', encoding='utf-8') as f:
                            f.write(str((singer_id, album_id, song_id)) + '\n')
    
                        with open(self.new_singer, 'a+', encoding='utf-8') as f:
                            f.write(str((singer_id, singer_name, singer_mid, country)) + '\n')
    
                elif len(singer) > 0:
                    s = singer[0]
                    singer_id = s.get('id')
    
                    singer_mid = s.get('mid')
                    singer_name = s.get('name')
                    country = country_dict[type]
                    with open(self.new_singer_album_song_table, 'a+', encoding='utf-8') as f:
                        f.write(str((singer_id, album_id, song_id)) + '\n')
    
                    with open(self.new_singer, 'a+', encoding='utf-8') as f:
                        f.write(str((singer_id, singer_name, singer_mid, country)) + '\n')
    
                with open(self.new_song, 'a+', encoding='utf-8') as f:
                    f.write(str((song_id, song_mid, song_name, song_orig, singernames, strMediaMid,
                                 is_only, interval, ranking, album_mid, album_name, album_desc, time_public)) + '\n')
                   
                with open(self.new_album, 'a+', encoding='utf-8') as f:
                    f.write(str((album_id, album_name, album_desc, album_mid, time_public)) + '\n')
    
        else:
            pass
