#!/bin/sh
cd /root/qqmusic/NewQQMusic
/root/qqmusic/venv/bin/python startDownload.py
