# -*- coding:utf-8 -*-
import pymysql


def insert_du_song():
    conn = pymysql.connect(host='127.0.0.1', user='root', password="Changeme_123",
                           database='music', port=3306, charset='utf8')

    cur = conn.cursor()
    with open('./du_song.csv', 'r', encoding='utf-8') as f:
        # song = f.readline()
        num = 0
        song_list = f.readlines()
        for song in song_list:
            # while song:

            if '"' in song:
                song = song.split('"')
                s0 = song[0].split(',')
                s2 = song[-1].split(',')

                s1 = []
                for i in song[1:-1]:
                    if len(i) < 2:
                        pass
                    else:
                        s1.append(i)
                n_song = s0[:-1] + s1 + s2[1:]
            else:
                n_song = song.split(',')

            if len(n_song) == 13:
                songid, songmid, songname, songorig, singernames, songMediaMid, \
                isonly, interval, ranking, albumid, albumname, albumdesc, time_public = n_song
                num += 1

                if not ranking:
                    ranking = 0

                sql = "INSERT INTO song(`song_id`,`song_mid`,`song_name`,`song_org`,`singer_names`,`str_media_mid`,`is_only`," \
                      "`interval`,`ranking`,`album_id`,`album_name`,`album_desc`,`pub_time`) " \
                      "VALUES (%d,%r,%r,%r,%r,%r,%s,%s,%s,%s,%r,%r,%r)" % \
                      (int(songid), songmid, songname, songorig, singernames, songMediaMid, isonly, interval,
                       ranking, albumid, albumname, albumdesc, time_public.strip())

                print(sql)
                try:
                    cur.execute(sql)
                    conn.commit()
                except:
                    with open('./insert_du_err.txt', 'a+', encoding='utf-8') as f:
                        f.write(sql + '\n')
                        f.flush()

            # song = f.readline()

        print(num)

    cur.close()
    conn.close()


if __name__ == '__main__':
    insert_du_song()
