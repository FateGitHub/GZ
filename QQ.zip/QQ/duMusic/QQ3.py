# -*- coding:utf-8 -*-
import requests
import json
import asyncio
import aiohttp
from pyquery import PyQuery as pq
import random


class YinYue:

    def __init__(self, url):
        self.music_url = url  # 音乐的url
        self.music_id = None  # 音乐的ID
        self.music_download_url = None  # 最终音乐的下载地址
        self.music_name = None  # 音乐的名字
        self.vkey = None  # 加密的参数
        self.params = None  # 提交的参数
        self.guid = '1' + ''.join(random.choice(['1', '2', '3', '4', '5', '6', '7', '8', '9']) for _ in range(9))

        self.headers = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36"}
        self.proxies = {"https": "https://127.0.0.1:1080"}

    def get_name(self):  # 获取歌曲的名字
        response = requests.get(url=self.music_url, headers=self.headers).content.decode('utf-8')

        doc = pq(response)
        # print(doc)

        self.music_name = doc('title').text().split('-')[0]  # 歌曲的名字

        print(self.music_name)

    def get_params(self):  # 获取加密的vkey
        self.params = self.music_url[self.music_url.rindex(
            '/') + 1:self.music_url.rindex('.')]  # 获取音乐的ID

        print(self.params)

        params_url = 'https://c.y.qq.com/base/fcgi-bin/fcg_music_express_mobile3.fcg?g_tk=5381&jsonpCallback=MusicJsonCallback' \
                     '&loginUin=0&hostUin=0&format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq&needNewCode=0&cid=205361747' \
                     '&callback=MusicJsonCallback&uin=5253&songmid=' + self.params + '&filename={}' + self.params + '.{}&guid=1671612333'

        music_type = {
            'C400': 'm4a',
            'M500': 'mp3',
            'M800': 'mpe',
            'A000': 'ape',
            'F000': 'flac'
        }  # m4a, mp3普通, mp3高, ape, flac
        music_vkey_urls = []  # 下载音乐的地址

        for k, v in music_type.items():
            music_url = params_url.format(k, v)
            music_vkey_urls.append([music_url, (k, v)])

        music_download_url = self.get_vkey(music_vkey_urls)
        print(music_download_url, '==========')

    def get_vkey(self, music_vkey_urls):  # 协程判断是否存在不同音乐品质的url
        vkey_result = []

        async def get(url):
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as resp:
                    if resp.status == 200:
                        html = await resp.read()
                        return html

        async def vkey_request(vkey_url_info):
            url = vkey_url_info[0]
            url_type = vkey_url_info[1]

            response = await get(url)
            response = response.decode('utf-8').split(')MusicJsonCallback(', maxsplit=1)[0].replace(
                'MusicJsonCallback(', '').rstrip(')')
            response = json.loads(response)

            vkey = response['data']['items'][0]['vkey']  # 加密的参数

            if vkey:
                vkey_result.append([vkey, url_type])
            else:
                # 不可下载
                pass

        tasks = [asyncio.ensure_future(vkey_request(vkey_url_info)) for vkey_url_info in music_vkey_urls]
        loop = asyncio.get_event_loop()
        loop.run_until_complete(asyncio.wait(tasks))
        if vkey_result:
            # music_download_url = result[-1]  # 默认下载最高品质
            
            return vkey_result[-1]
        else:
            return None

    def download_music(self):  # 音乐的下载
        response = requests.get(url=self.music_download_url, headers=self.headers, stream=True)
        with open(self.music_name + '.mp3', 'wb') as f:
            for check in response.iter_content(1024):
                f.write(check)


if __name__ == '__main__':
    yinyue = YinYue('https://y.qq.com/n/yqq/song/002B8Rsl0UKgJa.html')
    yinyue.get_name()
    yinyue.get_params()
    # yinyue.download_music()
