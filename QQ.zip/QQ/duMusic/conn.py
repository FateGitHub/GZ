# -*- coding:utf-8 -*-
import pymysql
conn = pymysql.connect(host='127.0.0.1', user='root', password="Changeme_123",database='music', port=3306, charset='utf8')
cur = conn.cursor()
print(cur)
sql="INSERT INTO song(`song_id`,`song_mid`,`song_name`,`song_org`,`singer_names`,`str_media_mid`,`is_only`,`interval`,`ranking`,`album_id`,`album_name`,`album_desc`,`pub_time`) VALUES (1204767,'0031jD8G3WtHXK','抽烟','抽烟','陈珊妮','0031jD8G3WtHXK',0,244,0,101599,'精选集1994-1999','','2000-01-01')"
cur.execute(sql)
conn.commit()
